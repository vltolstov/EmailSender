<?php $__env->startSection('addressbook-list'); ?>

    <?php $__currentLoopData = $addressbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addressbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($addressbook); ?>1</p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/addressbooks.blade.php ENDPATH**/ ?>