<br>
<hr>
<div>

    <p>Чтобы отписаться от получения рассылок, нажмите <a href="<?php echo e(route('unsubscribe')); ?>/<?php echo e($email); ?>">здесь</a></p>

</div>
<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/mailing-templates/unsubscribe-text.blade.php ENDPATH**/ ?>