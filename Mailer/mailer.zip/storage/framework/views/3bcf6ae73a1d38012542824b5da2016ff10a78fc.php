<?php $__env->startSection('contact-list'); ?>

    <h2>Список контактов</h2>

    <div class="list">
        <div class="row">
            <div class="col-lg-4 list-block"><p>Email</p></div>
            <div class="col-lg-8 list-block"><p>Адресная книга</p></div>
        </div>

        <?php if($contacts->count() > 0): ?>
            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-lg-4 list-block"><p><?php echo e($contact->email); ?></p></div>
                    <div class="col-lg-8 list-block"><p><?php echo e($contact->addressbook_name); ?></p></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($contacts->links()); ?>

        <?php else: ?>
            <div class="row">
                <div class="col-lg-12 list-block"><p>Контакты отсутствуют</p></div>
            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/contacts.blade.php ENDPATH**/ ?>