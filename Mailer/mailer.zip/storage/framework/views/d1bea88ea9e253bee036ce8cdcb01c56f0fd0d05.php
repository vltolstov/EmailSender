<?php $__env->startSection('addressbook-list'); ?>

    <h2>Список адресных книг</h2>

    <div class="list">
        <div class="row">
            <div class="col-lg-4 list-block"><p>Адресная книга</p></div>
            <div class="col-lg-2 list-block"><p>IP адресс</p></div>
            <div class="col-lg-1 list-block"><p>Порт</p></div>
            <div class="col-lg-4 list-block"><p>Хэш</p></div>
            <div class="col-lg-1 list-block"><p>&nbsp;</p></div>
        </div>

        <?php if($addressbooks->count() > 0): ?>
            <?php $__currentLoopData = $addressbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addressbook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-lg-4 list-block"><p><?php echo e($addressbook->name); ?></p></div>
                    <div class="col-lg-2 list-block"><p><?php echo e($addressbook->server_ip); ?></p></div>
                    <div class="col-lg-1 list-block"><p><?php echo e($addressbook->server_port); ?></p></div>
                    <div class="col-lg-4 list-block"><p><?php echo e($addressbook->addressbook_hash); ?></p></div>
                    <div class="col-lg-1 list-block">
                        <div class="control-buttons">
                            <form action="<?php echo e(route('addressbooks.destroy', $addressbook->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="delete-button"><span class="icon-exit"></span></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="row">
                <div class="col-lg-12 list-block"><p>Адресные книги отсутствуют</p></div>
            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-addressbook-form'); ?>

    <h2>Добавить новую адресную книгу</h2>

    <?php echo $__env->make('addressbooks.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/addressbooks/index.blade.php ENDPATH**/ ?>