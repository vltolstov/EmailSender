<?php $__env->startSection('mailing-lists'); ?>

    <h2>Рассылки</h2>

    <div class="row">
        <a href="<?php echo e(route('mailing-lists.create')); ?>" class="add-template-button">Создать рассылку</a>
    </div>


    <div class="list">
        <div class="row">
            <div class="col-lg-3 list-block"><p>Название рассылки</p></div>
            <div class="col-lg-2 list-block"><p>Адресная книга</p></div>
            <div class="col-lg-3 list-block"><p>Шаблон</p></div>
            <div class="col-lg-1 list-block"><p>Дата</p></div>
            <div class="col-lg-1 list-block"><p>Статус</p></div>
            <div class="col-lg-2 list-block"><p>&nbsp;</p></div>
        </div>

        <?php if($mailingLists->count() > 0): ?>
            <?php $__currentLoopData = $mailingLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mailingList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-lg-3 list-block"><p><?php echo e($mailingList->name); ?></p></div>
                    <div class="col-lg-2 list-block"><p><?php echo e($mailingList->addressbook_name); ?></p></div>
                    <div class="col-lg-3 list-block"><p><?php echo e($mailingList->mailing_template_name); ?></p></div>
                    <div class="col-lg-1 list-block"><p><?php echo e($mailingList->created_at->format('d-m-y')); ?></p></div>
                    <div class="col-lg-1 list-block"><p><?php echo e($mailingList->status); ?></p></div>
                    <div class="col-lg-2 list-block">
                        <div class="control-buttons">
                            <?php if($mailingList->status !== 'Отправлено'): ?>
                                <a href="<?php echo e(route('sendMailingList', $mailingList->id)); ?>"><span class="icon-play"></span></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('mailing-lists.edit', $mailingList->id)); ?>"><span class="icon-edit"></span></a>
                            <form action="<?php echo e(route('mailing-lists.destroy', $mailingList->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="delete-button"><span class="icon-exit"></span></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="row">
                <div class="col-lg-12 list-block"><p>Рассылки отсутствуют</p></div>
            </div>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/mailing-lists/index.blade.php ENDPATH**/ ?>