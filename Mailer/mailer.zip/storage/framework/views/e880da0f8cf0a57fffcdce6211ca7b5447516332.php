<?php $__env->startSection('templates'); ?>

    <h2>Шаблоны для рассылок</h2>

    <?php if($templates->count() > 0): ?>
        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-lg-12">
                    Шаблон
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="row">
            <div class="col-lg-12"><p>Шаблоны отсутствуют</p></div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/mailing-template.blade.php ENDPATH**/ ?>