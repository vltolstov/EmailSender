<br>
<hr>
<div>

    <p>Отпишись от меня, курва!</p>

</div>
<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views//mailing-templates/unsubscribe-text.blade.php ENDPATH**/ ?>