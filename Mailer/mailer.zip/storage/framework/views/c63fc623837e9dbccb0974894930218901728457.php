<?php if($paginator->hasPages()): ?>
    <div class="navi">
        <nav role="navigation" aria-label="Pagination Navigation">
            <?php if($paginator->onFirstPage()): ?>
                <span>
                    <?php echo __('pagination.previous'); ?>

                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">
                    <?php echo __('pagination.previous'); ?>

                </a>
            <?php endif; ?>

            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">
                    <?php echo __('pagination.next'); ?>

                </a>
            <?php else: ?>
                <span class="">
                    <?php echo __('pagination.next'); ?>

                </span>
            <?php endif; ?>
        </nav>
    </div>
<?php endif; ?>
<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/vendor/pagination/simple-tailwind.blade.php ENDPATH**/ ?>