<!DOCTYPE html>
<html lang="ru">

<head>

    <base href="<?php echo e($baseUrl); ?>">
    <title>Mailer</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>



    <script src="https://cdn.tiny.cloud/1/pwwklnveu0jc4p1ceg32skwkcquplljar7c0z299id0813yn/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-lg-2">
                <?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-lg-10">

                <?php $__env->startSection('addressbook-list'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('add-addressbook-form'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('contact-list'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('templates'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('add-template-form'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('edit-template-form'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('mailing-lists'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('add-mailinglist-form'); ?>
                <?php echo $__env->yieldSection(); ?>

                <?php $__env->startSection('edit-mailinglist-form'); ?>
                <?php echo $__env->yieldSection(); ?>

            </div>
        </div>
    </div>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

    <script>
        tinymce.init({
            selector: 'textarea',
            plugins: 'image autolink lists media table',
            toolbar: 'styleselect bold italic alignleft aligncenter alignright a11ycheck addcomment showcomments casechange checklist code export formatpainter image editimage pageembed permanentpen table tableofcontents',
            toolbar_mode: 'floating',
            tinycomments_mode: 'embedded',
            language: 'ru',
        });
    </script>

</body>
</html>
<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views//layouts/main.blade.php ENDPATH**/ ?>