<?php $__env->startSection('templates'); ?>

    <h2>Шаблоны для рассылок</h2>

    <div class="row">
        <a href="<?php echo e(route('mailing-templates.create')); ?>" class="add-template-button">Создать шаблон</a>
    </div>


    <div class="list">
        <div class="row">
            <div class="col-lg-8 list-block"><p>Название шаблона</p></div>
            <div class="col-lg-2 list-block"><p>Дата</p></div>
            <div class="col-lg-2 list-block"><p>&nbsp;</p></div>
        </div>

        <?php if($templates->count() > 0): ?>
            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-lg-8 list-block"><p><?php echo e($template->name); ?></p></div>
                    <div class="col-lg-2 list-block"><p><?php echo e($template->created_at); ?></p></div>
                    <div class="col-lg-2 list-block">
                        <div class="control-buttons">
                            <a href="<?php echo e(route('mailing-templates.edit', $template->id)); ?>"><span class="icon-edit"></span></a>
                            <a href="<?php echo e(route('copyTemplate', $template->id)); ?>"><span class="icon-copy"></span></a>
                            <form action="<?php echo e(route('mailing-templates.destroy', $template->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="delete-button"><span class="icon-exit"></span></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="row">
                <div class="col-lg-12 list-block"><p>Шаблоны отсутствуют</p></div>
            </div>
        <?php endif; ?>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/mailing-templates/index.blade.php ENDPATH**/ ?>