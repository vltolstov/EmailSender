<!DOCTYPE html>
<html lang="ru">

<head>

    <base href="<?php echo e($baseUrl); ?>">
    <title>Отмена подписки</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="align-center">Подписка отменена</h2>
            <p class="align-center">Электронная почта <?php echo e($email); ?> успешно удалена из рассылок</p>
        </div>
    </div>
</div>

<?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

</body>
</html>
<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/unsubscribe.blade.php ENDPATH**/ ?>