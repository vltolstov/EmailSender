<?php echo $content; ?>


<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/emails/default.blade.php ENDPATH**/ ?>