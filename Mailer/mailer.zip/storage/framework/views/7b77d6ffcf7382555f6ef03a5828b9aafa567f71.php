<ul class="sidebar">
    <li><a href="<?php echo e(route('addressbooks.index')); ?>">Адресные книги</a></li>
    <li>
        <a class="sidebarContacts" href="<?php echo e(route('contacts')); ?>">Контакты</a>
        <span class="reloadContacts reload">&nbsp;</span>
    </li>
    <li><a href="<?php echo e(route('blocked')); ?>">Заблокированные контакты</a></li>
    <li><a href="<?php echo e(route('mailing-templates.index')); ?>">Шаблоны</a></li>
    <li><a href="<?php echo e(route('mailing-lists.index')); ?>">Рассылки</a></li>
    <li><a href="<?php echo e(route('logout')); ?>">Выход</a></li>
</ul>
<?php /**PATH /Users/vladimir/Work/Repos/Laravel-Environment/EmailSender/Mailer/resources/views/sidebar.blade.php ENDPATH**/ ?>