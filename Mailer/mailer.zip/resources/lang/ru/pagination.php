<?php

return [
    'previous' => '<<<',
    'next' => '>>>',
];
