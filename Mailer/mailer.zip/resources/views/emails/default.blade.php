{!! $content !!}

