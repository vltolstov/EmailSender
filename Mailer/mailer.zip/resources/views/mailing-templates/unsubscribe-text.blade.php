<br>
<hr>
<div>

    <p>Чтобы отписаться от получения рассылок, нажмите <a href="{{route('unsubscribe')}}/{{$email}}">здесь</a></p>

</div>
