<ul class="sidebar">
    <li><a href="{{route('addressbooks.index')}}">Адресные книги</a></li>
    <li>
        <a class="sidebarContacts" href="{{route('contacts')}}">Контакты</a>
        <span class="reloadContacts reload">&nbsp;</span>
    </li>
    <li><a href="{{route('blocked')}}">Заблокированные контакты</a></li>
    <li><a href="{{route('mailing-templates.index')}}">Шаблоны</a></li>
    <li><a href="{{route('mailing-lists.index')}}">Рассылки</a></li>
    <li><a href="{{route('logout')}}">Выход</a></li>
</ul>
